/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#include <accelmag.h>

typedef struct accelmag_struct {
	int16 accel_x;
	int16 accel_y;
	int16 accel_z;
	int16 mag_x;
	int16 mag_y;
	int16 mag_z;
} t_accelmag;

t_accelmag accelmag_data;

/*******************************************************************************
* Function Name: accelmag_init
********************************************************************************
* Summary:
*        Configures the KMX61 and enables it
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void accelmag_init( void ) {
	uint8 d;
	
	I2C_Start();
	
	d = accelmag_read_reg(0);
	
	accelmag_write_reg(_CNTL1, 0x10);  //Set for +/- 2g
	accelmag_write_reg(_ODCNTL, 0x22); //Set for 50 Hz sample rate
	accelmag_write_reg(_STBY_REG, 0x00);  //Enable accel and mag
	
}



/*******************************************************************************
* Function Name: accelmag_task
********************************************************************************
* Summary:
*        Gets latest accel and mag data
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void accelmag_task( void ) {
	
	uint8 d[16];	
	
	accelmag_read_buf(_ACCEL_XOUT_L, 14, d);
	
	accelmag_data.accel_x = d[1];
	accelmag_data.accel_x <<= 8;
	accelmag_data.accel_x |= d[0];
	
	accelmag_data.accel_y = d[3];
	accelmag_data.accel_y <<= 8;
	accelmag_data.accel_y |= d[2];
	
	accelmag_data.accel_z = d[5];
	accelmag_data.accel_z <<= 8;
	accelmag_data.accel_z |= d[4];
	
	accelmag_data.mag_x = d[9];
	accelmag_data.mag_x <<= 8;
	accelmag_data.mag_x |= d[8];
	
	accelmag_data.mag_y = d[11];
	accelmag_data.mag_y <<= 8;
	accelmag_data.mag_y |= d[10];
	
	accelmag_data.mag_z = d[13];
	accelmag_data.mag_z <<= 8;
	accelmag_data.mag_z |= d[12];
	
	
	
}

/*******************************************************************************
* Function Name: accelmag_get_data
********************************************************************************
* Summary:
*        Returns the last data received from the accelerometer
*
* Parameters:
*  Index
*
* Return:
*  data value
*

*******************************************************************************/
int16 accelmag_get_data(int index) {

	switch (index) {
		default: return accelmag_data.accel_x; break;
		case 1:  return accelmag_data.accel_y; break;
		case 2:  return accelmag_data.accel_z; break;
		case 3:  return accelmag_data.mag_x; break;
		case 4:  return accelmag_data.mag_y; break;
		case 5:  return accelmag_data.mag_z; break;
	}
	
}

/*******************************************************************************
* Function Name: accelmag_read_reg
********************************************************************************
* Summary:
*        Reads a register over I2C
*
* Parameters:
*  Address
*
* Return:
*  reg result
*

*******************************************************************************/
uint8 accelmag_read_reg(int address) {
	uint8 d;
	uint8 status;

	status = SDA_Read();
	status = SCL_Read();

	if (I2C_MasterSendStart(ACCELMAG_I2C_ADDR, 0) != 0)
		return 0;
	if (I2C_MasterWriteByte(address) != 0)
		return 0;
	if (I2C_MasterSendRestart(ACCELMAG_I2C_ADDR, 1) != 0) 
		return 0;
	d = I2C_MasterReadByte(0);
	if (I2C_MasterSendStop() != 0)
		return 0;

	return d;
}

/*******************************************************************************
* Function Name: accelmag_write_reg
********************************************************************************
* Summary:
*        Writes a register over I2C
*
* Parameters:
*  Address, Data
*
* Return:
*  0 = success, else failed
*

*******************************************************************************/
int accelmag_write_reg(int address, uint8 d) {
	
	if (I2C_MasterSendStart(ACCELMAG_I2C_ADDR, 0) != 0)
		return 10;
	if (I2C_MasterWriteByte(address) != 0)
		return 11;
    if(I2C_MasterWriteByte(d) )
		return 14;
	if(I2C_MasterSendStop())
   		return 18;
	
	return 0;
}

/*******************************************************************************
* Function Name: accelmag_read_buf
********************************************************************************
* Summary:
*        Reads several registers over I2C
*
* Parameters:
*  Address, number of reads, Pointer to array
*
* Return:
*  0 = success, else failed
*

*******************************************************************************/
int accelmag_read_buf(int address, int count, uint8 d[]) {
	int i;
	uint8 status;

	status = SDA_Read();
	status = SCL_Read();

	if (I2C_MasterSendStart(ACCELMAG_I2C_ADDR, 0) != 0)
		return 10;
	if (I2C_MasterWriteByte(address) != 0)
		return 11;
	if (I2C_MasterSendRestart(ACCELMAG_I2C_ADDR, 1) != 0) 
		return 12;
	for (i=0;i<(count-1);i++) {
		d[i] = I2C_MasterReadByte(1);
	}
	d[count-1] = I2C_MasterReadByte(0);
	
	if (I2C_MasterSendStop() != 0)
		return 13;

	return 0;	
}



/* [] END OF FILE */
