/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#if !defined(accelmag_H)
#define accelmag_H
	
#include <project.h>
#include <kmx61.h>

#define ACCELMAG_I2C_ADDR 0x0E

/*******************************************************************************
* Function Name: accelmag_init
********************************************************************************
* Summary:
*        Configures the KMX61 and enables it
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void accelmag_init( void );



/*******************************************************************************
* Function Name: accelmag_task
********************************************************************************
* Summary:
*        Gets latest accel and mag data
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void accelmag_task( void );

/*******************************************************************************
* Function Name: accelmag_get_data
********************************************************************************
* Summary:
*        Returns the last data received from the accelerometer
*
* Parameters:
*  Index
*
* Return:
*  data value
*

*******************************************************************************/
int16 accelmag_get_data(int index);

/*******************************************************************************
* Function Name: accelmag_read_reg
********************************************************************************
* Summary:
*        Reads a register over I2C
*
* Parameters:
*  Address
*
* Return:
*  reg result
*

*******************************************************************************/
uint8 accelmag_read_reg(int address);

/*******************************************************************************
* Function Name: accelmag_write_reg
********************************************************************************
* Summary:
*        Writes a register over I2C
*
* Parameters:
*  Address, Data
*
* Return:
*  0 = success, else failed
*
*******************************************************************************/
int accelmag_write_reg(int address, uint8 d);

/*******************************************************************************
* Function Name: accelmag_read_buf
********************************************************************************
* Summary:
*        Reads several registers over I2C
*
* Parameters:
*  Address, number of reads, Pointer to array
*
* Return:
*  0 = success, else failed
*

*******************************************************************************/
int accelmag_read_buf(int address, int count, uint8 d[]);





#endif /* accelmag_H */
/* [] END OF FILE */
