/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#include <bendsensor.h>
#include <stdlib.h>

typedef struct bendsensor_struct {
	uint32 idac;
	uint32 raw;
} t_bendsensor;


t_bendsensor bendsensors[BENDSENSOR_NUM];

const int sensor_pins[10] = {
	4,
	0,
	1,
	5,
	7,
	11,
	10,
	6,
	16,
	12,
};
	
//0 = sensor, 1 = com
const int com_pins[20] = {
	0,  //0
	0,  //1
	1,  //2
	1,  //3
	0,  //4
	0,  //5
	0,  //6
	0,  //7
	1,  //8
	1,  //9
	0,  //10
	0,  //11
	0,  //12
	0,  //13
	1,  //14
	1,  //15
	0,  //16
	0,  //17
	0,  //18
	0,  //19
};


/*******************************************************************************
* Function Name: bendsensor_init
********************************************************************************
* Summary:
*        Stores initial baseline of sensors, estabilishes approximate max
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_init( void ) {
	int i;
	
	ADC_Start();
	IDAC_Start();
	AMux_Start();
	
	//Set coms to ground
	if (com_pins[0] == 1)  { CyPins_ClearPin(Sensor_0);  CyPins_SetPinDriveMode(Sensor_0 , PIN_DM_OD_LO); }
	if (com_pins[1] == 1)  { CyPins_ClearPin(Sensor_1);  CyPins_SetPinDriveMode(Sensor_1 , PIN_DM_OD_LO); }
	if (com_pins[2] == 1)  { CyPins_ClearPin(Sensor_2);  CyPins_SetPinDriveMode(Sensor_2 , PIN_DM_OD_LO); }
	if (com_pins[3] == 1)  { CyPins_ClearPin(Sensor_3);  CyPins_SetPinDriveMode(Sensor_3 , PIN_DM_OD_LO); }
	if (com_pins[4] == 1)  { CyPins_ClearPin(Sensor_4);  CyPins_SetPinDriveMode(Sensor_4 , PIN_DM_OD_LO); }
	if (com_pins[5] == 1)  { CyPins_ClearPin(Sensor_5);  CyPins_SetPinDriveMode(Sensor_5 , PIN_DM_OD_LO); }
	if (com_pins[6] == 1)  { CyPins_ClearPin(Sensor_6);  CyPins_SetPinDriveMode(Sensor_6 , PIN_DM_OD_LO); }
	if (com_pins[7] == 1)  { CyPins_ClearPin(Sensor_7);  CyPins_SetPinDriveMode(Sensor_7 , PIN_DM_OD_LO); }
	if (com_pins[8] == 1)  { CyPins_ClearPin(Sensor_8);  CyPins_SetPinDriveMode(Sensor_8 , PIN_DM_OD_LO); }
	if (com_pins[9] == 1)  { CyPins_ClearPin(Sensor_9);  CyPins_SetPinDriveMode(Sensor_9 , PIN_DM_OD_LO); }
	if (com_pins[10] == 1) { CyPins_ClearPin(Sensor_10); CyPins_SetPinDriveMode(Sensor_10, PIN_DM_OD_LO); }
	if (com_pins[11] == 1) { CyPins_ClearPin(Sensor_11); CyPins_SetPinDriveMode(Sensor_11, PIN_DM_OD_LO); }
	if (com_pins[12] == 1) { CyPins_ClearPin(Sensor_12); CyPins_SetPinDriveMode(Sensor_12, PIN_DM_OD_LO); }
	if (com_pins[13] == 1) { CyPins_ClearPin(Sensor_13); CyPins_SetPinDriveMode(Sensor_13, PIN_DM_OD_LO); }
	if (com_pins[14] == 1) { CyPins_ClearPin(Sensor_14); CyPins_SetPinDriveMode(Sensor_14, PIN_DM_OD_LO); }
	if (com_pins[15] == 1) { CyPins_ClearPin(Sensor_15); CyPins_SetPinDriveMode(Sensor_15, PIN_DM_OD_LO); }
	if (com_pins[16] == 1) { CyPins_ClearPin(Sensor_16); CyPins_SetPinDriveMode(Sensor_16, PIN_DM_OD_LO); }
	if (com_pins[17] == 1) { CyPins_ClearPin(Sensor_17); CyPins_SetPinDriveMode(Sensor_17, PIN_DM_OD_LO); }
	if (com_pins[18] == 1) { CyPins_ClearPin(Sensor_18); CyPins_SetPinDriveMode(Sensor_18, PIN_DM_OD_LO); }
	if (com_pins[19] == 1) { CyPins_ClearPin(Sensor_19); CyPins_SetPinDriveMode(Sensor_19, PIN_DM_OD_LO); }
	
	
	bendsensor_pwr_up();
	
	//Initialize current
	for (i=0;i<BENDSENSOR_NUM;i++) {
		bendsensors[i].idac = BENDSENSOR_INIT_IDAC<<8;
	}

	bendsensor_measure_all();
	
	
}

/*******************************************************************************
* Function Name: bendsensor_measure_all
********************************************************************************
* Summary:
*        Measures all bend sensors
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_measure_all( void ) {
	int i;
	
	bendsensor_pwr_up();
	
	for (i=0;i<BENDSENSOR_NUM;i++) {
		bendsensors[i].raw = bendsensor_measure_single(i);
	}
	
	bendsensor_pwr_dn();
	
		
}

/*******************************************************************************
* Function Name: bendsensor_measure_single
********************************************************************************
* Summary:
*        Measures a single sensor. Assumes the analog system is already powered up
*
* Parameters:
*  Sensor number
*
* Return:
*  int result
*

*******************************************************************************/
int32 bendsensor_measure_single(int sensorNum) {
	
	int32 result = 0;
	
	AMux_Select(sensor_pins[sensorNum] );
	
	

	IDAC_SetValue(bendsensors[sensorNum].idac>>8); //Update current
	CyDelayUs(5);	//Settling time delay
	ADC_StartConvert();
	ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);	//Stall until complete
	result = ADC_GetResult32();
	
	   
	return result;	
	
	
}

/*******************************************************************************
* Function Name: bendsensor_get_ohms
********************************************************************************
* Summary:
*        Returns sensor value in ohms
*
* Parameters:
*  Sensor number
*
* Return:
*  int result
*

*******************************************************************************/
int32 bendsensor_get_ohms(int sensorNum) {
	
	int32 a;
	
	//Keep value within int32 limits
	a = bendsensors[sensorNum].raw * BENDSENSOR_IDAC_RES_INV_SHR8;
	
	if ( (a*BENDSENSOR_VREF) > 0x7FFFFF) {
		//Overflow case
		a *= BENDSENSOR_VREF;
		a /= BENDSENSOR_ADC_MAX_VALUE; //should be optimized to a shift
		a <<= 8;
	} else {
		a <<= 8;
		a *= BENDSENSOR_VREF;
		a /= BENDSENSOR_ADC_MAX_VALUE; //should be optimized to a shift
	}
	a /= (bendsensors[sensorNum].idac>>8); 
	return a;
	
}


/*******************************************************************************
* Function Name: bendsensor_pwr_up
********************************************************************************
* Summary:
*        Powers up analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_pwr_up( void ) {
	
	ADC_Wakeup();
	IDAC_Wakeup();
	
	CyDelayUs(10);
	
}

/*******************************************************************************
* Function Name: bendsensor_pwr_dn
********************************************************************************
* Summary:
*        Powers dn analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_pwr_dn( void ) {
	
	ADC_Sleep();
	IDAC_Sleep();
	
}


/* [] END OF FILE */
