/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#ifndef bendsensor_H
#define bendsensor_H
	
#include <project.h>


#define BENDSENSOR_NUM 10
	
#define BENDSENSOR_INIT_IDAC 50
	
//Maximum value the ADC can return
#define BENDSENSOR_ADC_MAX_VALUE 65536
	
//Voltage reference of the ADC
#define BENDSENSOR_VREF 1.024
	
// 1 divided by the idac resolution idac res is 1uA/bit so 1/0.000001 shifted right 8 bits
#define BENDSENSOR_IDAC_RES_INV_SHR8 3906
	
	



/*******************************************************************************
* Function Name: bendsensor_init
********************************************************************************
* Summary:
*        Initializes measurement engine
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void bendsensor_init( void );


/*******************************************************************************
* Function Name: bendsensor_measure_all
********************************************************************************
* Summary:
*        Measures all bend sensors
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_measure_all( void );

/*******************************************************************************
* Function Name: bendsensor_measure_single
********************************************************************************
* Summary:
*        Measures a single sensor. Assumes the analog system is already powered up
*
* Parameters:
*  Sensor number
*
* Return:
*  int result
*

*******************************************************************************/
int32 bendsensor_measure_single(int sensorNum);

/*******************************************************************************
* Function Name: bendsensor_get_ohms
********************************************************************************
* Summary:
*        Returns sensor value in ohms
*
* Parameters:
*  Sensor number
*
* Return:
*  int result
*

*******************************************************************************/
int32 bendsensor_get_ohms(int sensorNum);


/*******************************************************************************
* Function Name: bendsensor_pwr_up
********************************************************************************
* Summary:
*        Powers up analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_pwr_up( void );

/*******************************************************************************
* Function Name: bendsensor_pwr_dn
********************************************************************************
* Summary:
*        Powers dn analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void bendsensor_pwr_dn( void );

#endif /* bendsensors_H */
/* [] END OF FILE */
