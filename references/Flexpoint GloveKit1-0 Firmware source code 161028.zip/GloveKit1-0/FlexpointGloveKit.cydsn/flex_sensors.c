/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <flex_sensors.h>
#include <stdlib.h>

typedef struct flex_sensor_struct {
	uint8 idac;
	uint32 raw;
	uint32 baseline;
	uint32 max;
	uint32 hist;
	uint32 value;
} t_flex_sensor;


t_flex_sensor sensors[FLEX_SENSORS_NUM];

uint32 flex_sensors_flags = 0;

/*******************************************************************************
* Function Name: flex_sensors_init
********************************************************************************
* Summary:
*        Stores initial baseline of sensors, estabilishes approximate max
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_init( void ) {
	int i;
	
	ADC_Start();
	IDAC_Start();
	AMux_Start();
	
	//Common_Write(0);
	
	
	//Initialize current
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		sensors[i].idac = 0x80; //Midscale
	}

	flex_sensors_measure_all();
	
	//Initialize baseline and max's
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		sensors[i].baseline = sensors[i].raw;
		sensors[i].max = sensors[i].baseline*FLEX_SENSORS_MAX_INIT;
		sensors[i].hist = sensors[i].raw;
	}
	
	
}

/*******************************************************************************
* Function Name: flex_sensors_measure_all
********************************************************************************
* Summary:
*        Measures all sensors
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_measure_all( void ) {
	int i;
	int delta_sum;
	
	flex_sensors_pwr_up();
	
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		sensors[i].raw = flex_sensors_measure_single(i);
	}
	
	flex_sensors_pwr_dn();
	
	//Check for movement
	delta_sum = 0;
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		if (sensors[i].raw < FLEX_SENSORS_OPEN_SENSOR) {
			delta_sum += abs(sensors[i].hist - sensors[i].raw);
			sensors[i].hist = sensors[i].raw;
		}
	}
	
	if (delta_sum > FLEX_SENSORS_MOVE_DELTA) {
		flex_sensors_flags |= FLEX_SENSORS_FLAGS_MOVEMENT;		
	}
	
}

/*******************************************************************************
* Function Name: flex_sensors_measure_single
********************************************************************************
* Summary:
*        Measures a single sensor. Assumes the analog system is already powered up
*
* Parameters:
*  Sensor number
*
* Return:
*  int result
*

*******************************************************************************/
uint32 flex_sensors_measure_single(int sensorNum) {
	
	uint32 result = 0;
	int resample = 1;
	
	AMux_Select(sensorNum);

	while (resample == 1) {
		IDAC_SetValue(sensors[sensorNum].idac); //Update current
		CyDelayUs(5);	//Settling time delay
		ADC_StartConvert();
		ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);	//Stall until complete
		result = ADC_GetResult16();
		resample = 0;
		
		
		if (result > FLEX_SENSORS_VALUE_HIGH && sensors[sensorNum].idac > 1) {
			sensors[sensorNum].idac--;
			resample = 1;
		}
		if (result < FLEX_SENSORS_VALUE_LOW && sensors[sensorNum].idac < 0xFF) {
			sensors[sensorNum].idac++;
			resample = 1;
		} 
	}
    
	return (result<<8) / sensors[sensorNum].idac;	
	
	
}

/*******************************************************************************
* Function Name: flex_sensors_manage_limits
********************************************************************************
* Summary:
*        Updates baselines and maxes
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_manage_limits( void ) {
	int i;
	
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		
		//First check if sensor is open or shorted
		if (sensors[i].raw > FLEX_SENSORS_OPEN_SENSOR) {
			
			sensors[i].baseline = FLEX_SENSORS_OPEN_SENSOR;
			sensors[i].max = sensors[i].baseline + 1;
		
		} else if (sensors[i].raw > FLEX_SENSORS_SHORT_SENSOR) {

			if (sensors[i].raw < sensors[i].baseline) {
				sensors[i].baseline = sensors[i].raw;
				sensors[i].max = sensors[i].baseline*FLEX_SENSORS_MAX_INIT;	
			}
		}
	}
	
}


/*******************************************************************************
* Function Name: flex_sensors_convert_scaled
********************************************************************************
* Summary:
*        Scales flex sensor values based on baseline and max
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_convert_scaled( void ) {
	int i;
	
	for (i=0;i<FLEX_SENSORS_NUM;i++) {
		sensors[i].value = (sensors[i].raw - sensors[i].baseline) * FLEX_SENSORS_SCALE_RANGE / (sensors[i].max - sensors[i].baseline);
					
		if (sensors[i].value > FLEX_SENSORS_SCALE_RANGE)
			sensors[i].value = FLEX_SENSORS_SCALE_RANGE;
		
	}
}

/*******************************************************************************
* Function Name: flex_sensors_diff
********************************************************************************
* Summary:
*        Computes a differential value based on two sensors
*
* Parameters:
*  Positive sensor number, Negative sensor number
*
* Return:
*  signed integer differential value
*

*******************************************************************************/
int32 flex_sensors_diff(int pos_sensor_num, int neg_sensor_num) {
	
	if (sensors[pos_sensor_num].raw > FLEX_SENSORS_OPEN_SENSOR) {
		return (-(int32)sensors[neg_sensor_num].value);
	} else if (sensors[neg_sensor_num].raw > FLEX_SENSORS_OPEN_SENSOR) {
		return (int32)sensors[pos_sensor_num].value;
	} else {
		return  ( ( (int32)sensors[pos_sensor_num].value) - ( (int32)sensors[neg_sensor_num].value) );
	}
}


/*******************************************************************************
* Function Name: flex_sensors_is_moving
********************************************************************************
* Summary:
*        Checks if movement flag is set
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
int flex_sensors_is_moving( void ) {
	int r = (flex_sensors_flags & FLEX_SENSORS_FLAGS_MOVEMENT);
	
	//Clear flag
	flex_sensors_flags &= ~FLEX_SENSORS_FLAGS_MOVEMENT;
	return r;
}


/*******************************************************************************
* Function Name: flex_sensors_pwr_up
********************************************************************************
* Summary:
*        Powers up analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_pwr_up( void ) {
	
	ADC_Wakeup();
	IDAC_Wakeup();
	
	CyDelayUs(10);
	
}

/*******************************************************************************
* Function Name: flex_sensors_pwr_dn
********************************************************************************
* Summary:
*        Powers dn analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_pwr_dn( void ) {
	
	ADC_Sleep();
	IDAC_Sleep();
	
}


/* [] END OF FILE */
