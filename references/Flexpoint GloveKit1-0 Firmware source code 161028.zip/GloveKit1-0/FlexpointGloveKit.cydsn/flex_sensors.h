/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(flex_sensors_H)
#define flex_sensors_H
	
#include <project.h>


#define FLEX_SENSORS_NUM 2
	
#define FLEX_SENSORS_VALUE_HIGH ( (int)(0xFFF*0.9) )
#define FLEX_SENSORS_VALUE_LOW  ( (int)(0xFFF*0.5) )
	
//Above this means the sensor is open  
#define FLEX_SENSORS_OPEN_SENSOR 0x6FE00

//Below this means the sensor is shorted
#define FLEX_SENSORS_SHORT_SENSOR 100
	
#define FLEX_SENSORS_MAX_INIT 8	//Value to scale the baseline to guess on where the sensor max is

	
#define FLEX_SENSORS_MOVE_DELTA (20*FLEX_SENSORS_NUM)
	
#define FLEX_SENSORS_SCALE_RANGE 32767
	
	
	
//Define flags
#define FLEX_SENSORS_FLAGS_MOVEMENT 0x0001
	
	


/*******************************************************************************
* Function Name: flex_sensors_init
********************************************************************************
* Summary:
*        Stores initial baseline of sensors, estabilishes approximate max
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void flex_sensors_init( void );


/*******************************************************************************
* Function Name: flex_sensors_measure_all
********************************************************************************
* Summary:
*        Measures all sensors
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_measure_all( void );

/*******************************************************************************
* Function Name: flex_sensors_measure_single
********************************************************************************
* Summary:
*        Measures a single sensor. Assumes the analog system is already powered up
*
* Parameters:
*  Sensor number
*
* Return:
*  uint32 result
*

*******************************************************************************/
uint32 flex_sensors_measure_single(int sensorNum);

/*******************************************************************************
* Function Name: flex_sensors_manage_limits
********************************************************************************
* Summary:
*        Updates baselines and maxes
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_manage_limits( void );


/*******************************************************************************
* Function Name: flex_sensors_convert_scaled
********************************************************************************
* Summary:
*        Scales flex sensor values based on baseline and max
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_convert_scaled( void );

/*******************************************************************************
* Function Name: flex_sensors_diff
********************************************************************************
* Summary:
*        Computes a differential value based on two sensors
*
* Parameters:
*  Positive sensor number, Negative sensor number
*
* Return:
*  signed integer differential value
*

*******************************************************************************/
int32 flex_sensors_diff(int pos_sensor_num, int neg_sensor_num);


/*******************************************************************************
* Function Name: flex_sensors_is_moving
********************************************************************************
* Summary:
*        Checks if movement flag is set
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
int flex_sensors_is_moving( void );


/*******************************************************************************
* Function Name: flex_sensors_pwr_up
********************************************************************************
* Summary:
*        Powers up analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_pwr_up( void );

/*******************************************************************************
* Function Name: flex_sensors_pwr_dn
********************************************************************************
* Summary:
*        Powers dn analog system
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void flex_sensors_pwr_dn( void );

#endif /* flex_sensors_H */
/* [] END OF FILE */
