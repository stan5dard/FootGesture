/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#include <glove.h>
#include <bendsensor.h>
#include <stdlib.h>

typedef struct glove_sensor_struct {
	uint32 raw;
	uint32 min;
	uint32 max;
	uint32 ave;
	uint32 value;
	uint32 flags;
} t_glove_sensor;


t_glove_sensor glove_sensors[BENDSENSOR_NUM];

uint32 glove_flags = 0;

/*******************************************************************************
* Function Name: glove_init
********************************************************************************
* Summary:
*        Stores initial baseline of sensors, estabilishes approximate max
*
* Parameters:
*  None
*
* Return:
*  None
*

*******************************************************************************/
void glove_init( void ) {
	int i;
	
	bendsensor_init();
	
	//Initialize baseline and max's
	for (i=0;i<BENDSENSOR_NUM;i++) {
		glove_sensors[i].min = bendsensor_get_ohms(i);
		glove_sensors[i].max = glove_sensors[i].min * GLOVE_SENSOR_MAX_INIT;
		glove_sensors[i].ave = glove_sensors[i].min;
		glove_sensors[i].value = 0;
		glove_sensors[i].flags = 0;
	}
	
	
}

/*******************************************************************************
* Function Name: glove_task
********************************************************************************
* Summary:
*        Acquires sensors and processes results
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void glove_task( void ) {
	int i;
	
	bendsensor_measure_all();
	
	for (i=0;i<BENDSENSOR_NUM;i++) {
		
		glove_sensors[i].raw = bendsensor_get_ohms(i);
		
		//Update min if raw is below
		if (glove_sensors[i].raw < glove_sensors[i].min) {
			glove_sensors[i].min = glove_sensors[i].raw;
		}
		
		//Update max if raw is above
		if (glove_sensors[i].raw > glove_sensors[i].max) {
			glove_sensors[i].max = glove_sensors[i].raw + 1;
		}
		
		
		
		//Scale between min and max
		if ( (glove_sensors[i].raw - glove_sensors[i].min) > 65535) {
			//Overflow case
			glove_sensors[i].value = (glove_sensors[i].raw - glove_sensors[i].min) * 256 / (glove_sensors[i].max - glove_sensors[i].min);
			glove_sensors[i].value <<= 8;
		} else {
			//No overflow
			glove_sensors[i].value = (glove_sensors[i].raw - glove_sensors[i].min) * 32768 / (glove_sensors[i].max - glove_sensors[i].min);
			
			if (glove_sensors[i].value > 32767) {
				glove_sensors[i].value = 32767;
			}
			
		}
	}
}

/*******************************************************************************
* Function Name: glove_force_calibration_max
********************************************************************************
* Summary:
*        Sets the max to the current sensor value
*
* Parameters:
*  None
*
* Return:
*  void
*

*******************************************************************************/
void glove_force_calibration_max( void ) {
	int i;
	for (i=0;i<BENDSENSOR_NUM;i++) {
		glove_sensors[i].max = glove_sensors[i].raw;
		
		if (glove_sensors[i].max < glove_sensors[i].min * GLOVE_SENSOR_MAX_INIT) {
			glove_sensors[i].max = glove_sensors[i].min * GLOVE_SENSOR_MAX_INIT;
		}
	}
}

/*******************************************************************************
* Function Name: glove_force_calibration_min
********************************************************************************
* Summary:
*        Sets the min to the current sensor value
*
* Parameters:
*  None
*
* Return:
*  void
*

*******************************************************************************/
void glove_force_calibration_min( void ) {
	int i;
	for (i=0;i<BENDSENSOR_NUM;i++) {
		glove_sensors[i].min = glove_sensors[i].raw;	
		
		if (glove_sensors[i].max < glove_sensors[i].min * GLOVE_SENSOR_MAX_INIT) {
			glove_sensors[i].max = glove_sensors[i].min * GLOVE_SENSOR_MAX_INIT;
		}
	}
}



/*******************************************************************************
* Function Name: glove_num_sensors
********************************************************************************
* Summary:
*        Returns the number of bend sensors
*
* Parameters:
*  void
*
* Return:
*  int
*

*******************************************************************************/
int glove_num_sensors( void ) {
	return BENDSENSOR_NUM;
}
	
	

/*******************************************************************************
* Function Name: glove_sensors_value
********************************************************************************
* Summary:
*        Returns the current value of the sensor after conditioning
*
* Parameters:
*  int sensor_num - which sensor to return the value of
*
* Return:
*  int32
*

*******************************************************************************/
int32 glove_sensors_value(int sensor_num) {

	return glove_sensors[sensor_num].value;

}

/* [] END OF FILE */
