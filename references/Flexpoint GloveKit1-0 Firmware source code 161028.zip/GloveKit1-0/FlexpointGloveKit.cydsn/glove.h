/* ========================================
 *
 * Copyright Flexpoint Sensor Systems, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF FLEXPOINT SENSOR SYSTEMS.
 *
 * ========================================
*/

#if !defined(glove_H)
#define glove_H
	
#include <project.h>
#include <bendsensor.h>

//Defines the initial maximum based on the minimum on power up
#define GLOVE_SENSOR_MAX_INIT 2
	
	
//Define flags
	
	


/*******************************************************************************
* Function Name: glove_init
********************************************************************************
* Summary:
*        Stores initial baseline of bend sensors, estabilishes approximate max
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void glove_init( void );



/*******************************************************************************
* Function Name: glove_task
********************************************************************************
* Summary:
*        Acquires sensors and processes results
*
* Parameters:
*  void
*
* Return:
*  void
*

*******************************************************************************/
void glove_task( void );



/*******************************************************************************
* Function Name: glove_force_calibration_max
********************************************************************************
* Summary:
*        Sets the max to the current sensor value
*
* Parameters:
*  None
*
* Return:
*  void
*

*******************************************************************************/
void glove_force_calibration_max( void );

/*******************************************************************************
* Function Name: glove_force_calibration_min
********************************************************************************
* Summary:
*        Sets the min to the current sensor value
*
* Parameters:
*  None
*
* Return:
*  void
*

*******************************************************************************/
void glove_force_calibration_min( void );


/*******************************************************************************
* Function Name: glove_num_sensors
********************************************************************************
* Summary:
*        Returns the number of bend sensors
*
* Parameters:
*  void
*
* Return:
*  int
*

*******************************************************************************/
int glove_num_sensors( void );

/*******************************************************************************
* Function Name: glove_sensors_value
********************************************************************************
* Summary:
*        Returns the current value of the sensor after conditioning
*
* Parameters:
*  int sensor_num - which sensor to return the value of
*
* Return:
*  int32
*

*******************************************************************************/
int32 glove_sensors_value(int sensor_num);



#endif /* glove_H */
/* [] END OF FILE */
