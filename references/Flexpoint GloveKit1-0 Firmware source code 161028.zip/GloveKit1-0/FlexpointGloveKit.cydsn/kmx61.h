
 /* registers */
//
#define _INS1 0x01
//
#define _INS2 0x02
//
#define _STATUS_REG 0x03
//
#define _ACCEL_XOUT_L 0x0A
//
#define _ACCEL_XOUT_H 0x0B
//
#define _ACCEL_YOUT_L 0x0C
//
#define _ACCEL_YOUT_H 0x0D
//
#define _ACCEL_ZOUT_L 0x0E
//
#define _ACCEL_ZOUT_H 0x0F
//
#define _TEMP_OUT_L 0x10
//
#define _TEMP_OUT_H 0x11
//
#define _MAG_XOUT_L 0x12
//
#define _MAG_XOUT_H 0x13
//
#define _MAG_YOUT_L 0x14
//
#define _MAG_YOUT_H 0x15
//
#define _MAG_ZOUT_L 0x16
//
#define _MAG_ZOUT_H 0x17
//
#define _XOUT_HPF_L 0x18
//
#define _XOUT_HPF_H 0x19
//
#define _YOUT_HPF_L 0x1A
//
#define _YOUT_HPF_H 0x1B
//
#define _ZOUT_HPF_L 0x1C
//
#define _ZOUT_HPF_H 0x1D
//
#define _SN_1 0x24
//
#define _SN_2 0x25
//
#define _SN_3 0x26
//
#define _SN_4 0x27
//
#define _INL 0x28
//
#define _STBY_REG 0x29
//
#define _CNTL1 0x2A
//
#define _CNTL2 0x2B
//
#define _ODCNTL 0x2C
//
#define _INC1 0x2D
//
#define _INC2 0x2E
//
#define _INC3 0x2F
//
#define _COTR 0x3C
//
#define _WUFTH 0x3D
//
#define _WUFC 0x3E
//
#define _BTH 0x3F
//
#define _BTSC 0x40
//
#define _TEMP_EN_CNTL 0x4C
//
#define _SELF_TEST 0x60
//
#define _BUF_THRESH_H 0x76
//
#define _BUF_THRESH_L 0x77
//
#define _BUF_CTRL1 0x78
//
#define _BUF_CTRL2 0x79
//
#define _BUF_CLEAR 0x7A
//
#define _BUF_STATUS_REG 0x7B
//
#define _BUF_STATUS_H 0x7C
//
#define _BUF_STATUS_L 0x7D
//
#define _BUF_READ 0x7E
//
#define _BUF_STATUS_L 0x7D

 /* registers bits */ 
//Buffer is not full
#define _INS1_BFI_0 (0x0 << 6)
//Buffer is full
#define _INS1_BFI_1 (0x1 << 6)
//Buffer watermark not reached
#define _INS1_WMI_0 (0x0 << 5)
//Buffer watermark reached
#define _INS1_WMI_1 (0x1 << 5)
//
#define _INS1_DRDY_ACCEL (0x01 << 4)
//
#define _INS1_DRDY_MAG (0x01 << 3)
//
#define _INS1_WUFS (0x01 << 1)
//
#define _INS2_XNWU (0x01 << 5)
//
#define _INS2_XPWU (0x01 << 4)
//
#define _INS2_YNWU (0x01 << 3)
//
#define _INS2_YPWU (0x01 << 2)
//
#define _INS2_ZNWU (0x01 << 1)
//
#define _INS2_ZPWU (0x01 << 0)
//
#define _STATUS_REG_INT (0x01 << 4)
//
#define _STBY_REG_ACT_STBY_OPERATING_MODE (0x0 << 7)
//
#define _STBY_REG_ACT_STBY_STAND_BY_MODE (0x1 << 7)
//
#define _STBY_REG_MAG_STBY_OPERATING_MODE (0x0 << 1)
//
#define _STBY_REG_MAG_STBY_STAND_BY_MODE (0x1 << 1)
//
#define _STBY_REG_ACCEL_STBY_OPERATING_MODE (0x0 << 0)
//
#define _STBY_REG_ACCEL_STBY_STAND_BY_MODE (0x1 << 0)
//2g 12 bit
#define _CNTL1_GSEL_2G (0x0 << 0)
//4g 12bit
#define _CNTL1_GSEL_4G (0x1 << 0)
//8g 12bit
#define _CNTL1_GSEL_8G (0x2 << 0)
//8g 14bit
#define _CNTL1_GSEL_8G14B (0x3 << 0)
//Software Reset function
#define _CNTL2_SRST (0x01 << 7)
//ST polarity control
#define _CNTL2_STPOL (0x01 << 6)
//enables the command test function
#define _CNTL2_COTC (0x01 << 4)
//
#define _CNTL2_OWUF_0P781 (0x0 << 0)
//
#define _CNTL2_OWUF_1P563 (0x1 << 0)
//
#define _CNTL2_OWUF_3P125 (0x2 << 0)
//
#define _CNTL2_OWUF_6P25 (0x3 << 0)
//
#define _CNTL2_OWUF_12P5 (0x4 << 0)
//
#define _CNTL2_OWUF_25 (0x5 << 0)
//
#define _CNTL2_OWUF_50 (0x6 << 0)
//
#define _CNTL2_OWUF_100 (0x7 << 0)
//12.5Hz
#define _ODCNTL_OSM_12P5 (0x0 << 4)
//25Hz
#define _ODCNTL_OSM_25 (0x1 << 4)
//50Hz
#define _ODCNTL_OSM_50 (0x2 << 4)
//100Hz
#define _ODCNTL_OSM_100 (0x3 << 4)
//200Hz
#define _ODCNTL_OSM_200 (0x4 << 4)
//400Hz
#define _ODCNTL_OSM_400 (0x5 << 4)
//800Hz
#define _ODCNTL_OSM_800 (0x6 << 4)
//1600Hz
#define _ODCNTL_OSM_1600 (0x7 << 4)
//0.781Hz
#define _ODCNTL_OSM_0P781 (0x8 << 4)
//1.563Hz
#define _ODCNTL_OSM_1P563 (0x9 << 4)
//3.125Hz
#define _ODCNTL_OSM_3P125 (0xa << 4)
//6.25Hz
#define _ODCNTL_OSM_6P25 (0xb << 4)
//12.5Hz
#define _ODCNTL_OSA_12P5 (0x0 << 4)
//25Hz
#define _ODCNTL_OSA_25 (0x1 << 4)
//50Hz
#define _ODCNTL_OSA_50 (0x2 << 4)
//100Hz
#define _ODCNTL_OSA_100 (0x3 << 4)
//200Hz
#define _ODCNTL_OSA_200 (0x4 << 4)
//400Hz
#define _ODCNTL_OSA_400 (0x5 << 4)
//800Hz
#define _ODCNTL_OSA_800 (0x6 << 4)
//1600Hz
#define _ODCNTL_OSA_1600 (0x7 << 4)
//0.781Hz
#define _ODCNTL_OSA_0P781 (0x8 << 4)
//1.563Hz
#define _ODCNTL_OSA_1P563 (0x9 << 4)
//3.125Hz
#define _ODCNTL_OSA_3P125 (0xa << 4)
//6.25Hz
#define _ODCNTL_OSA_6P25 (0xb << 4)
//
#define _INC1_BFI1 (0x01 << 4)
//
#define _INC1_WMI1 (0x01 << 4)
//
#define _INC1_IEN1 (0x01 << 4)
//
#define _INC1_IEA1 (0x01 << 4)
//
#define _INC1_IEL1 (0x01 << 4)
//
#define _INC1_DRDY_A1 (0x01 << 4)
//
#define _INC1_DRDY_M1 (0x01 << 4)
//
#define _INC1_WUFS_BTS1 (0x01 << 4)
//
#define _INC2_BFI2 (0x01 << 4)
//
#define _INC2_WMI2 (0x01 << 4)
//
#define _INC2_IEN2 (0x01 << 4)
//
#define _INC2_IEA2 (0x01 << 4)
//
#define _INC2_IEL2 (0x01 << 4)
//
#define _INC2_DRDY_A2 (0x01 << 4)
//
#define _INC2_DRDY_M2 (0x01 << 4)
//
#define _INC2_WUFS/BTS2 (0x01 << 4)
//
#define _INC3_NXWUE (0x01 << 5)
//
#define _INC3_PXWUE (0x01 << 4)
//
#define _INC3_NYWUE (0x01 << 3)
//
#define _INC3_PYWUE (0x01 << 2)
//
#define _INC3_NZWUE (0x01 << 1)
//
#define _INC3_PZWUE (0x01 << 0)
//
#define _BUF_CTRL1_BUFE (0x01 << 0)
//
#define _BUF_CTRL1_BUF_FIE (0x01 << 0)
//
#define _BUF_CTRL1_BUF_M_FIFO (0x0 << 0)
//
#define _BUF_CTRL1_BUF_M_STREAM (0x1 << 0)
//
#define _BUF_CTRL1_BUF_M_TRIGGER (0x2 << 0)
//
#define _BUF_CTRL1_BUF_M_FILO (0x3 << 0)

 /*registers bit masks */
//
#define _INS1_0_MASK 0x80
//BFI - indicates that the buffer is full. This bit is cleared when the data is read or the interrupt
#define _INS1_BFI_MASK 0x40
//
#define _INS1_WMI_MASK 0x20
//None
#define _INS1_DRDY_ACCEL_MASK 0x10
//None
#define _INS1_DRDY_MAG_MASK 0x8
//None
#define _INS1_WUFS_MASK 0x2
//None
#define _INS2_XNWU_MASK 0x20
//None
#define _INS2_XPWU_MASK 0x10
//None
#define _INS2_YNWU_MASK 0x8
//None
#define _INS2_YPWU_MASK 0x4
//None
#define _INS2_ZNWU_MASK 0x2
//None
#define _INS2_ZPWU_MASK 0x1
//None
#define _STATUS_REG_INT_MASK 0x10
//
#define _STBY_REG_ACT_STBY_MASK 0x80
//
#define _STBY_REG_MAG_STBY_MASK 0x2
//
#define _STBY_REG_ACCEL_STBY_MASK 0x1
//
#define _CNTL1_BTSE_MASK 0x80
//
#define _CNTL1_WUFE_MASK 0x40
//
#define _CNTL1_DRDYE_MASK 0x20
//
#define _CNTL1_GSEL_MASK 0x3
//None
#define _CNTL2_SRST_MASK 0x80
//None
#define _CNTL2_STPOL_MASK 0x40
//None
#define _CNTL2_COTC_MASK 0x10
//Output Data Rate at which the wake up (motion detection) performs its function
#define _CNTL2_OWUF_MASK 0x7
//
#define _ODCNTL_OSM_MASK 0xf0
//
#define _ODCNTL_OSA_MASK 0xf0
//None
#define _INC1_BFI1_MASK 0x10
//None
#define _INC1_WMI1_MASK 0x10
//None
#define _INC1_IEN1_MASK 0x10
//None
#define _INC1_IEA1_MASK 0x10
//None
#define _INC1_IEL1_MASK 0x10
//None
#define _INC1_DRDY_A1_MASK 0x10
//None
#define _INC1_DRDY_M1_MASK 0x10
//None
#define _INC1_WUFS_BTS1_MASK 0x10
//None
#define _INC2_BFI2_MASK 0x10
//None
#define _INC2_WMI2_MASK 0x10
//None
#define _INC2_IEN2_MASK 0x10
//None
#define _INC2_IEA2_MASK 0x10
//None
#define _INC2_IEL2_MASK 0x10
//None
#define _INC2_DRDY_A2_MASK 0x10
//None
#define _INC2_DRDY_M2_MASK 0x10
//None
#define _INC2_WUFS_BTS2_MASK 0x10
//None
#define _INC3_NXWUE_MASK 0x20
//None
#define _INC3_PXWUE_MASK 0x10
//None
#define _INC3_NYWUE_MASK 0x8
//None
#define _INC3_PYWUE_MASK 0x4
//None
#define _INC3_NZWUE_MASK 0x2
//None
#define _INC3_PZWUE_MASK 0x1
//None
#define _BUF_CTRL1_BUFE_MASK 0x1
//None
#define _BUF_CTRL1_BUF_FIE_MASK 0x1
//
#define _BUF_CTRL1_BUF_M_MASK 0x1