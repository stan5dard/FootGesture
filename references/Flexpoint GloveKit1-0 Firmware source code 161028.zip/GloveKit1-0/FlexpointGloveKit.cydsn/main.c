/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*   Enumerates as a Virtual Com port.
*   
*
* Related Document:
*  Universal Serial Bus Specification Revision 2.0 
*  Universal Serial Bus Class Definitions for Communications Devices 
*  Revision 1.2
*
*******************************************************************************/

#include <project.h>
#include "stdio.h"
#include <glove.h>
#include <accelmag.h>

#define VERSION_HIGH 1
#define VERSION_LOW 2



void process_cmdStr(uint8 cmdStr[], uint16 cmdCount);



/* The size of the buffer is equal to maximum packet size of the 
*  IN and OUT bulk endpoints. 
*/
#define BUFFER_LEN  64u


uint8 enabled = {0};
int echo_enabled = 1;

int version_high;
int version_low;

int main()
{
	int i;
    uint16 usbCount;
    uint8 dataStr[BUFFER_LEN];
    uint8 usbStr[20];
	uint8 cmdStr[128];
	uint16 cmdCount;
	
	
	version_high = VERSION_HIGH;
	version_low = VERSION_LOW;
	
    
    /* Enable Global Interrupts */
    CyGlobalIntEnable;                        

    /* Start USBFS Operation with 3V operation */
    USBUART_Start(0u, USBUART_3V_OPERATION);

    
	/* Wait for Device to enumerate */
    while(!USBUART_GetConfiguration());

    /* Enumeration is done, enable OUT endpoint for receive data from Host */
    USBUART_CDC_Init();
	
	cmdCount = 0;
	
	glove_init();
	accelmag_init();
	
    /* Main Loop: */
    for(;;)
    {
        
		glove_task();  //Acquire sensors and process results
		accelmag_task();
		
		//Build packet
		sprintf( (char*)dataStr, "DATA");
		
		
		if ( (USBUART_CDCIsReady() != 0) && enabled)                /* Wait till component is ready to send more data to the PC */
		{
			
			USBUART_PutData(dataStr, strlen( (char*)dataStr) ); //Send header
			
			for (i=0;i<glove_num_sensors();i++) {
			
				while (USBUART_CDCIsReady() == 0) {};
									
				sprintf( (char*)dataStr, "[%d:%ld]", i, glove_sensors_value(i) );
				USBUART_PutData(dataStr, strlen( (char*)dataStr) );       					/* Send data back to PC */
				
			}
			
			for (i=0;i<6;i++) {
			
				while (USBUART_CDCIsReady() == 0) {};
									
				sprintf( (char*)dataStr, "[%d:%d]", i+glove_num_sensors(), accelmag_get_data(i) );
				USBUART_PutData(dataStr, strlen( (char*)dataStr) );  
				
			}
			
			while (USBUART_CDCIsReady() == 0) {};
			sprintf( (char*)dataStr, "[%d:0]\r\n", 6+glove_num_sensors() );  //Report right hand for now
			USBUART_PutData(dataStr, strlen( (char*)dataStr) ); //Send end of line
		}
		
		
		//Handle communication from PC
		if(USBUART_DataIsReady() != 0u)               /* Check for input data from PC */
        {   
            usbCount = USBUART_GetAll(usbStr);           /* Read received data and re-enable OUT endpoint */
            if(usbCount != 0u)
            {
				
				//Any character we receive disables data stream
				enabled = 0;
				
				//Echo characters if Echo is enabled
				if (echo_enabled) {
					
					//Scan for cr
					for (i=0;i<usbCount;i++) {
						
						if (usbStr[i] >= ' ') {
							cmdStr[cmdCount++] = usbStr[i];
						}
						
						if (usbStr[i] == '\n') {
							usbStr[usbCount++] = '\r';
																					
							process_cmdStr(cmdStr, cmdCount);
							
							cmdCount = 0;
							break;
						}
						
						
						if (usbStr[i] == '\r') {
							usbStr[usbCount++] = '\n';
														
							process_cmdStr(cmdStr, cmdCount);
							
							cmdCount = 0;
							break;
						}
					}
					
					
					while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
		            USBUART_PutData(usbStr, usbCount);       /* Send data back to PC */
					
				}
				
							
			}
        }
	}
}

void process_cmdStr(uint8 cmdStr[], uint16 cmdCount) {
	
	if ( (cmdCount >= 9) && (strncmp( (char*)cmdStr, "flexpoint", 9) == 0) ) {
		enabled = 0;
						
		strncpy( (char*)cmdStr, " USB BENDSENSOR\r\n", 17);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
			
	}
	
	if ( (cmdCount >= 6) && (strncmp( (char*)cmdStr, "enable", 6) == 0) ) {
								
		strncpy( (char*)cmdStr, " ENABLED\r\n", 11);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
		
		enabled = 1;
	}
	
	if ( (cmdCount >= 3) && (strncmp( (char*)cmdStr, "ver", 3) == 0) ) {
		
		sprintf( (char*)cmdStr, " VER %d.%d\r\n", version_high, version_low);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
	}
	
	if ( (cmdCount >= 6) && (strncmp( (char*)cmdStr, "calmin", 6) == 0) ) {
		glove_force_calibration_min();	
		
		strncpy( (char*)cmdStr, " CALMIN\r\n", 10);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
	}
	
	if ( (cmdCount >= 6) && (strncmp( (char*)cmdStr, "calmax", 6) == 0) ) {
		glove_force_calibration_max();
		
		strncpy( (char*)cmdStr, " CALMAX\r\n", 10);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
	}
	
	if ( (cmdCount >= 6) && (strncmp( (char*)cmdStr, "bootloader", 10) == 0) ) {
		
		
		strncpy( (char*)cmdStr, " BOOTLOADER\r\n", 13);
		while(USBUART_CDCIsReady() == 0u) {};    /* Wait till component is ready to send more data to the PC */ 
        USBUART_PutData(cmdStr, strlen( (char*) cmdStr) );       /* Send data back to PC */
		
		CyDelay(1000);
		
		Bootloadable_Load();
		
	}
	
}





/* [] END OF FILE */
